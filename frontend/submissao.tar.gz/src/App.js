import logo from "./logo.svg";
import "./App.css";
import "./styles.css";
import LadingPage from "./LadingPage";
import Formulario from "./Formulario.js";
import Perfil from "./Perfil.js";

function App() {
  return (
    <div className="App">
      <LadingPage />
    </div>
  );
}

export default App;
